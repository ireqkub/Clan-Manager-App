# Wolvesville Clan Administrative Dashboard

A minimal, blue-and-white themed administrative dashboard for managing Wolvesville clans via the official API. This web application provides clan administrators with powerful tools to manage members, automate flair deductions, sync quest participation, and monitor clan activity.

## 🎯 Project Overview

This dashboard streamlines clan management by automating key administrative tasks including:
- **Bot Authentication**: Secure login using Wolvesville bot tokens
- **Clan Selection**: Visual grid interface for selecting authorized clans
- **Member Management**: Comprehensive member overview with quest status tracking
- **Flair Deduction Engine**: Automated currency deduction and emoji assignment
- **Quest Participation Sync**: Intelligent quest participation management
- **Activity Monitoring**: Real-time ledger and activity log tracking

## 🎨 Design Specifications

### Framework & Styling
- **Bootstrap 5** (CDN) for responsive UI components
- **Custom CSS** with blue-and-white color scheme
- **Flat design** with card-based layouts
- **Sticky sidebar** navigation for easy access

### Color Palette
- **Primary Background**: `#F8FAFC` (Ghost White)
- **Accent Blue**: `#007BFF` (Royal Blue Interactive Elements)
- **Text Color**: `#334155` (Slate Gray for readability)
- **Gradient Colors**: `#99CDE2`, `#6683D1`, `#008183`, `#00668E`, `#004068`

## 🚀 Current Features

### 1. Authentication System (`index.html`)
- **Bot Token Validation**: Uses `POST /items/redeemApiHat` endpoint
- **Session Management**: Secure token storage in sessionStorage
- **Error Handling**: Clear feedback for invalid tokens or network issues

### 2. Clan Selection (`clans.html`)
- **Visual Grid Layout**: Bootstrap cards displaying clan information
- **Member Capacity**: Progress bars showing `memberCount/50`
- **Quick Access**: Click-to-select clan functionality
- **Real-time Data**: Fetches from `GET /clans/authorized`

### 3. Member Management (`members.html`)
Five integrated sections provide comprehensive clan administration:

#### Section 1: Member List
- **Member Table**: Username, Level, Flair, Quest Status
- **Status Indicators**: Online/offline status with visual indicators
- **Quick Actions**: Individual quest participation toggles
- **API Integration**: `GET /clans/{clanId}/members`

#### Section 2: Flair Deduction Engine
- **Currency Detection**: Parses coin (©) and gem (G) values from flair strings
- **Automated Deductions**: 
  - Coin Mode: Deducts configurable © and adds 📙 emoji
  - Gem Mode: Deducts configurable G and adds 📘 emoji
- **Smart Filtering**: Skips members with existing emojis
- **Change Preview**: Shows pending changes before application

#### Section 3: Emoji Removal Tool
- **Bulk Removal**: Remove ALL emojis (📙📘📕) from member flairs
- **Preview System**: Shows affected members before removal
- **Safe Operations**: Confirmation required before bulk changes

#### Section 4: Quest Participation Sync
- **Intelligent Logic**:
  - 📙 or 📘 in flair → `participateInClanQuests = true`
  - 📕 in flair → `participateInClanQuests = false`
  - No emoji → Maintains current status
- **Bulk Operations**: Sync all members with single click
- **API Integration**: Uses `PUT /clans/{clanId}/members/{memberId}/participateInQuests`

#### Section 5: Ledger & Log Management (Enhanced)
- **Time Range Logic**: 
  - Default start: Latest FLAIR_EDITED event timestamp
  - Custom range: User-editable start and end datetime
- **Timezone Handling**: 
  - **Input**: Accepts GMT+7 (Thailand Time) for user convenience
  - **Display**: All times shown in GMT+7 format
  - **Storage**: Internal storage in UTC+0 for API compatibility
  - **Export**: Option to export in UTC+0 (Excel compatible) or GMT+7 (local time)
- **Update Flair Function**: 
  - Processes DONATE entries within time range
  - Updates member flair with gold (©) and gems (G)
  - Shows confirmation dialog: "[Username] | [Old Flair] → [New Flair]"
  - Allows apply/deny before API calls
- **Real-time Updates**: Automatic refresh with member data
- **Donation Tracking**: Donations increase update counts automatically
- **Export Functionality**: CSV export with timezone options
- **Filter Options**: 
  - Ledger: Donations Only (DONATE type) or All Entries
  - Activity Log: Flair Changes, Quest Actions, or All Actions

### 4. Data Export System (`export.html`)
- **Excel Export**: Export members, ledger, and activity logs to Excel format
- **Date Range Filtering**: Custom date ranges with quick presets (Today, Yesterday, This Week, etc.)
- **Statistics Dashboard**: Total members, active members, total donations
- **Modern Interface**: Clean design with export preview cards
- **File Downloads**: Automatic Excel file generation with timestamps

### 5. Enhanced Export Functionality (`members.html`)
- **CSV Export**: Export ledger data directly from the member management page
- **Timezone Options**: Choose between UTC+0 (Excel compatible) or GMT+7 (local time)
- **Real-time Processing**: Export current filtered view of ledger entries
- **Automatic Downloads**: Files named with timestamp for easy organization

#### Section 2: Flair Deduction Engine
- **Currency Detection**: Parses coin (©) and gem (G) values from flair strings
- **Automated Deductions**: 
  - Coin Mode: Deducts 600© and adds 📙 emoji
  - Gem Mode: Deducts 180G and adds 📘 emoji
- **Smart Filtering**: Skips members with existing emojis
- **Change Preview**: Shows pending changes before application

#### Section 3: Quest Participation Sync
- **Intelligent Logic**:
  - 📙 or 📘 in flair → `participateInClanQuests = true`
  - 📕 in flair → `participateInClanQuests = false`
  - No emoji → Maintains current status
- **Bulk Operations**: Sync all members with single click
- **API Integration**: Uses `PUT /clans/{clanId}/members/{memberId}/participateInQuests`

#### Section 4: Ledger & Activity Log
- **Recent Ledger**: Shows last 10 entries from `GET /clans/{clanId}/ledger`
- **Activity Monitoring**: Displays recent clan actions from `GET /clans/{clanId}/logs`
- **Real-time Updates**: Automatic refresh with member data

## 🔧 Technical Implementation

### Timezone Handling
```javascript
// GMT+7 to UTC conversion
convertGMT7ToUTC(gmt7Time) {
    const gmt7Date = new Date(gmt7Time);
    const utcTime = gmt7Date.getTime() - (7 * 60 * 60 * 1000);
    return new Date(utcTime);
}

// UTC to GMT+7 conversion for display
convertUTCToGMT7(utcTime) {
    const utcDate = new Date(utcTime);
    const gmt7Time = utcDate.getTime() + (7 * 60 * 60 * 1000);
    return new Date(gmt7Time);
}

// Format for display (GMT+7)
formatTimeForDisplay(date) {
    return date.toLocaleString('th-TH', {
        timeZone: 'Asia/Bangkok',
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    });
}
```

### Flair Parsing Logic
```javascript
function parseFlair(flairString) {
    const coinMatch = flairString.match(/(\d+)©/);
    const gemMatch = flairString.match(/(\d+)G/);
    
    return {
        coins: coinMatch ? parseInt(coinMatch[1]) : 0,
        gems: gemMatch ? parseInt(gemMatch[1]) : 0,
        hasGoldEmoji: flairString.includes('📙'),
        hasGemEmoji: flairString.includes('📘'),
        hasOptoutEmoji: flairString.includes('📕')
    };
}
```

### API Endpoints Used
- `POST /items/redeemApiHat` - Bot authentication
- `GET /clans/authorized` - List authorized clans
- `GET /clans/{clanId}/members` - Get clan members
- `PUT /clans/{clanId}/members/{memberId}/participateInQuests` - Update quest participation
- `GET /clans/{clanId}/ledger` - Get clan ledger
- `GET /clans/{clanId}/logs` - Get clan activity logs
- `PUT /clans/{clanId}/members/{memberId}/flair` - Update member flair

## 📁 File Structure
```
wolvesville-clan-admin/
├── index.html              # Login page
├── clans.html              # Clan selection page
├── members.html            # Main member management page
├── css/
│   └── style.css          # Custom styling and Bootstrap overrides
├── js/
│   ├── auth.js            # Authentication module
│   ├── clans.js           # Clan selection module
│   └── members.js         # Member management with flair engine
└── README.md              # Project documentation
```

## 🚀 Deployment Instructions

1. **Upload Files**: Upload all files to your web server
2. **Access Dashboard**: Navigate to `index.html` to begin
3. **Authentication**: Enter your Wolvesville bot token
4. **Select Clan**: Choose from your authorized clans
5. **Manage Members**: Use the comprehensive member management tools

## 🔒 Security Features

- **Token Storage**: Secure sessionStorage for bot tokens
- **Authentication Checks**: Automatic redirect for unauthenticated users
- **Error Handling**: Comprehensive error messages and recovery
- **Rate Limiting**: Sequential API calls to prevent rate limiting

## 🎯 Key Benefits

1. **Automation**: Reduces manual administrative work
2. **Accuracy**: Eliminates human error in flair calculations
3. **Efficiency**: Bulk operations for large clans
4. **Monitoring**: Real-time activity tracking
5. **User-Friendly**: Intuitive interface with visual feedback

## 🔮 Future Enhancements

Potential improvements for future versions:
- Manual flair editing capabilities
- Advanced filtering and search
- Export functionality for reports
- Real-time notifications
- Multi-clan management from single interface
- Custom deduction rules configuration

## 🛠️ Technical Requirements

- **Modern Browser**: Chrome, Firefox, Safari, Edge (latest versions)
- **Internet Connection**: Required for API access
- **Wolvesville Bot Token**: Valid bot authorization token
- **CORS Support**: API must support cross-origin requests

## 📞 Support

For issues or questions regarding this administrative dashboard, please refer to the Wolvesville API documentation and ensure your bot has the necessary permissions for clan management operations.

---

**Note**: This is a client-side only application that interfaces with the Wolvesville API. All data is fetched and displayed in real-time without server-side storage.