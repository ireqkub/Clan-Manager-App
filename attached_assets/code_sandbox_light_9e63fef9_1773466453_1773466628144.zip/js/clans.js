// Clan Selection Module
class ClanManager {
    constructor() {
        this.apiBase = 'https://api.wolvesville.com';
        this.authManager = authManager;
        
        this.init();
    }

    init() {
        // Check authentication
        if (!this.authManager.isAuthenticated()) {
            window.location.href = 'index.html';
            return;
        }

        // Setup event listeners
        document.getElementById('logoutBtn')?.addEventListener('click', () => {
            this.authManager.logout();
        });

        document.getElementById('refreshClansBtn')?.addEventListener('click', () => {
            this.loadClans();
        });

        document.getElementById('retryBtn')?.addEventListener('click', () => {
            this.loadClans();
        });

        // Load clans on page load
        this.loadClans();
    }

    async loadClans() {
        const loadingState = document.getElementById('loadingState');
        const clanGrid = document.getElementById('clanGrid');
        const emptyState = document.getElementById('emptyState');
        const refreshBtn = document.getElementById('refreshClansBtn');
        const spinner = refreshBtn.querySelector('.spinner-border');

        // Show loading state
        loadingState.classList.remove('d-none');
        clanGrid.classList.add('d-none');
        emptyState.classList.add('d-none');
        refreshBtn.disabled = true;
        spinner.classList.remove('d-none');

        try {
            const response = await fetch(`${this.apiBase}/clans/authorized`, {
                headers: this.authManager.getHeaders()
            });

            if (!response.ok) {
                if (response.status === 401) {
                    // Token expired or invalid
                    this.authManager.logout();
                    return;
                }
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }

            const clans = await response.json();

            if (clans.length === 0) {
                // Show empty state
                loadingState.classList.add('d-none');
                emptyState.classList.remove('d-none');
            } else {
                // Render clan cards
                this.renderClanCards(clans);
                loadingState.classList.add('d-none');
                clanGrid.classList.remove('d-none');
            }

        } catch (error) {
            console.error('Error loading clans:', error);
            this.showAlert('Failed to load clans. Please check your connection and try again.', 'danger');
            loadingState.classList.add('d-none');
            emptyState.classList.remove('d-none');
        } finally {
            refreshBtn.disabled = false;
            spinner.classList.add('d-none');
        }
    }

    renderClanCards(clans) {
        const clanGrid = document.getElementById('clanGrid');
        clanGrid.innerHTML = '';

        clans.forEach(clan => {
            const clanCard = this.createClanCard(clan);
            clanGrid.appendChild(clanCard);
        });
    }

    createClanCard(clan) {
        const card = document.createElement('div');
        card.className = 'col-md-6 col-lg-4';
        
        const memberCount = clan.memberCount || 0;
        const maxMembers = 50;
        const memberPercentage = (memberCount / maxMembers) * 100;

        card.innerHTML = `
            <div class="card h-100 shadow-sm border-0 clan-card" style="cursor: pointer; transition: transform 0.2s;" data-clan-id="${clan.id}">
                <div class="card-body p-4">
                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <div>
                            <h5 class="card-title text-primary fw-bold mb-1">${clan.name}</h5>
                            <span class="badge bg-gradient-primary">${clan.tag}</span>
                        </div>
                        <div class="text-end">
                            <small class="text-muted">Members</small>
                            <div class="fw-bold text-primary">${memberCount}/${maxMembers}</div>
                        </div>
                    </div>
                    
                    <div class="progress mb-3" style="height: 8px;">
                        <div class="progress-bar bg-gradient-primary" role="progressbar" 
                             style="width: ${memberPercentage}%" aria-valuenow="${memberCount}" 
                             aria-valuemin="0" aria-valuemax="${maxMembers}">
                        </div>
                    </div>
                    
                    <div class="d-flex justify-content-between align-items-center">
                        <small class="text-muted">Click to manage</small>
                        <i class="bi bi-arrow-right-circle text-primary fs-5"></i>
                    </div>
                </div>
            </div>
        `;

        // Add click event
        card.addEventListener('click', () => {
            this.selectClan(clan.id, clan.name);
        });

        // Add hover effect
        const clanCard = card.querySelector('.clan-card');
        clanCard.addEventListener('mouseenter', () => {
            clanCard.style.transform = 'translateY(-2px)';
            clanCard.style.boxShadow = '0 4px 16px rgba(0,0,0,0.15)';
        });

        clanCard.addEventListener('mouseleave', () => {
            clanCard.style.transform = 'translateY(0)';
            clanCard.style.boxShadow = '0 2px 8px rgba(0,0,0,0.1)';
        });

        return card;
    }

    selectClan(clanId, clanName) {
        // Store selected clan
        this.authManager.setSelectedClanId(clanId);
        
        // Store clan info for display in member management
        sessionStorage.setItem('wolvesville_selected_clan_name', clanName);
        
        // Redirect to member management
        window.location.href = 'members.html';
    }

    showAlert(message, type) {
        const alertContainer = document.getElementById('alertContainer');
        if (!alertContainer) return;

        const alertDiv = document.createElement('div');
        alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
        alertDiv.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        alertContainer.appendChild(alertDiv);
    }
}

// Initialize clan manager
const clanManager = new ClanManager();