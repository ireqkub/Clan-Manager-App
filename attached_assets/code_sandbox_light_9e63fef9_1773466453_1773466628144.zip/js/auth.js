// Authentication Module
class AuthManager {
    constructor() {
        this.apiBase = 'https://api.wolvesville.com';
        this.tokenKey = 'wolvesville_bot_token';
        this.clanIdKey = 'wolvesville_selected_clan';
        
        this.init();
    }

    init() {
        // Check if already authenticated
        const token = sessionStorage.getItem(this.tokenKey);
        if (token && window.location.pathname.includes('index.html')) {
            this.redirectToClanSelection();
        }

        // Setup login form
        const loginForm = document.getElementById('loginForm');
        if (loginForm) {
            loginForm.addEventListener('submit', (e) => this.handleLogin(e));
        }
    }

    async handleLogin(event) {
        event.preventDefault();
        
        const token = document.getElementById('botToken').value.trim();
        const loginBtn = document.getElementById('loginBtn');
        const spinner = loginBtn.querySelector('.spinner-border');
        
        // Show loading state
        loginBtn.disabled = true;
        spinner.classList.remove('d-none');
        this.hideAlert();

        try {
            // Validate token with redeemApiHat endpoint
            const response = await fetch(`${this.apiBase}/items/redeemApiHat`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bot ${token}`,
                    'Content-Type': 'application/json'
                }
            });

            if (response.status == 204) {
                // Token is valid
                sessionStorage.setItem(this.tokenKey, token);
                this.showAlert('Authentication successful! Redirecting...', 'success');
                
                setTimeout(() => {
                    this.redirectToClanSelection();
                }, 1500);
            } else {
                // Invalid token
                const errorText = await response.text();
                this.showAlert('Invalid bot token. Please check your token and try again.' + response.status, 'danger');
                
                // Reset form state
                loginBtn.disabled = false;
                spinner.classList.add('d-none');
            }
        } catch (error) {
            console.error('Authentication error:', error);
            this.showAlert('Network error. Please check your connection and try again.', 'danger');
            
            // Reset form state
            loginBtn.disabled = false;
            spinner.classList.add('d-none');
        }
    }

    redirectToClanSelection() {
        window.location.href = 'clans.html';
    }

    getToken() {
        return sessionStorage.getItem(this.tokenKey);
    }

    getHeaders() {
        const token = this.getToken();
        return {
            'Authorization': `Bot ${token}`,
            'Content-Type': 'application/json'
        };
    }

    logout() {
        sessionStorage.removeItem(this.tokenKey);
        sessionStorage.removeItem(this.clanIdKey);
        window.location.href = 'index.html';
    }

    showAlert(message, type) {
        const alertContainer = document.getElementById('alertContainer');
        if (!alertContainer) return;

        const alertDiv = document.createElement('div');
        alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
        alertDiv.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        alertContainer.appendChild(alertDiv);
    }

    hideAlert() {
        const alertContainer = document.getElementById('alertContainer');
        if (alertContainer) {
            alertContainer.innerHTML = '';
        }
    }

    // Check if user is authenticated
    isAuthenticated() {
        return !!this.getToken();
    }

    // Get selected clan ID
    getSelectedClanId() {
        return sessionStorage.getItem(this.clanIdKey);
    }

    // Set selected clan ID
    setSelectedClanId(clanId) {
        sessionStorage.setItem(this.clanIdKey, clanId);
    }
}

// Initialize authentication manager
const authManager = new AuthManager();