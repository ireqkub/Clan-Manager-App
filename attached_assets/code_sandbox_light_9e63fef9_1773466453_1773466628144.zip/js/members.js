// Member Management Module with Flair Deduction Engine
class MemberManager {
    constructor() {
        this.apiBase = 'https://api.wolvesville.com';
        this.authManager = authManager;
        this.members = [];
        this.pendingChanges = [];
        this.pendingEmojiRemovals = [];
        this.ledger = [];
        this.logs = [];
        this.localSessionLog = [];
        this.pendingManualChanges = [];
        this.currentLedgerFilter = 'all';
        this.currentLogFilter = 'all';
        this.lastActivityTime = null;
        this.startTimeFilter = null; // New: start time for ledger processing
        this.endTimeFilter = null;   // New: end time for ledger processing
        this.flairChanges = []; // New: store flair changes before API calls
        
        // Timezone constants
        this.GMT7_OFFSET = 7 * 60 * 60 * 1000; // 7 hours in milliseconds
        this.UTC_OFFSET = 0;
        
        this.init();
    }

    init() {
        // Check authentication and clan selection
        if (!this.authManager.isAuthenticated() || !this.authManager.getSelectedClanId()) {
            window.location.href = 'index.html';
            return;
        }

        // Display clan name
        const clanName = sessionStorage.getItem('wolvesville_selected_clan_name') || 'Unknown Clan';
        document.getElementById('clanNameDisplay').textContent = clanName;

        // Setup event listeners
        this.setupEventListeners();

        // Load initial data
        this.loadMembers();
        this.loadLedger();
        this.loadLogs();
        
        // Set default time range after data loads
        setTimeout(() => {
            this.setDefaultTimeRange();
        }, 2000);
    }

    // Timezone conversion utilities
    convertGMT7ToUTC(gmt7Time) {
        // Convert GMT+7 time to UTC time
        const gmt7Date = new Date(gmt7Time);
        const utcTime = gmt7Date.getTime() - this.GMT7_OFFSET;
        return new Date(utcTime);
    }

    convertUTCToGMT7(utcTime) {
        // Convert UTC time to GMT+7 time
        const utcDate = new Date(utcTime);
        const gmt7Time = utcDate.getTime() + this.GMT7_OFFSET;
        return new Date(gmt7Time);
    }

    formatTimeForDisplay(date, useGMT7 = true) {
        // Format time for display, default to GMT+7
        const displayDate = useGMT7 ? this.convertUTCToGMT7(date) : date;
        return displayDate.toLocaleString('th-TH', {
            timeZone: 'Asia/Bangkok',
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit'
        });
    }

    formatTimeForInput(date, useGMT7 = true) {
        // Format time for input fields, default to GMT+7
        const inputDate = useGMT7 ? this.convertUTCToGMT7(date) : date;
        return inputDate.toISOString().slice(0, 16); // YYYY-MM-DDTHH:MM format
    }

    setupEventListeners() {
        // Navigation
        document.getElementById('logoutBtn')?.addEventListener('click', () => {
            this.authManager.logout();
        });

        document.getElementById('backToClansBtn')?.addEventListener('click', () => {
            window.location.href = 'clans.html';
        });

        document.getElementById('refreshMembersBtn')?.addEventListener('click', () => {
            this.loadMembers();
        });

        // Flair deduction
        document.getElementById('analyzeFlairBtn')?.addEventListener('click', () => {
            this.analyzeFlairChanges();
        });

        document.getElementById('applyChangesBtn')?.addEventListener('click', () => {
            this.applyFlairChanges();
        });

        document.getElementById('denyChangesBtn')?.addEventListener('click', () => {
            this.denyFlairChanges();
        });

        // Flair deduction
        document.getElementById('analyzeFlairBtn')?.addEventListener('click', () => {
            this.analyzeFlairChanges();
        });

        document.getElementById('applyChangesBtn')?.addEventListener('click', () => {
            this.applyFlairChanges();
        });

        document.getElementById('denyChangesBtn')?.addEventListener('click', () => {
            this.denyFlairChanges();
        });

        // Emoji removal
        document.getElementById('analyzeEmojiRemovalBtn')?.addEventListener('click', () => {
            this.analyzeEmojiRemoval();
        });

        document.getElementById('applyEmojiRemovalBtn')?.addEventListener('click', () => {
            this.applyEmojiRemoval();
        });

        document.getElementById('denyEmojiRemovalBtn')?.addEventListener('click', () => {
            this.denyEmojiRemoval();
        });

        // Quest sync
        document.getElementById('syncAllQuestsBtn')?.addEventListener('click', () => {
            this.syncAllQuests();
        });

        // Ledger/Log management
        document.getElementById('refreshDataBtn')?.addEventListener('click', () => {
            this.loadLedgerAndLogs();
        });

        document.getElementById('updateFlairBtn')?.addEventListener('click', () => {
            this.processLedgerForFlairUpdates();
        });

        document.getElementById('changeTimeBtn')?.addEventListener('click', () => {
            this.changeTimeFilter();
        });

        document.getElementById('commitChangesBtn')?.addEventListener('click', () => {
            this.commitPendingChanges();
        });

        // Ledger filters
        document.getElementById('filterDonationsBtn')?.addEventListener('click', () => {
            this.filterLedger('donations');
        });

        document.getElementById('filterAllBtn')?.addEventListener('click', () => {
            this.filterLedger('all');
        });

        // Log filters
        document.getElementById('filterFlairBtn')?.addEventListener('click', () => {
            this.filterLogs('flair');
        });

        document.getElementById('filterQuestBtn')?.addEventListener('click', () => {
            this.filterLogs('quest');
        });

        document.getElementById('filterAllActionsBtn')?.addEventListener('click', () => {
            this.filterLogs('all');
        });

        // Export functionality
        document.getElementById('exportLedgerBtn')?.addEventListener('click', () => {
            const useUTC = confirm('Export ledger data:\n\nClick "OK" for UTC+0 (Excel compatible)\nClick "Cancel" for GMT+7 (Local time)');
            this.exportLedgerData(useUTC);
        });

        // Pending changes
        document.getElementById('applyPendingBtn')?.addEventListener('click', () => {
            this.applyPendingChanges();
        });

        document.getElementById('denyPendingBtn')?.addEventListener('click', () => {
            this.denyPendingChanges();
        });
    }

    // Flair Parsing Logic
    parseFlair(flairString) {
        if (!flairString || typeof flairString !== 'string') {
            return { coins: 0, gems: 0, hasGoldEmoji: false, hasGemEmoji: false, hasOptoutEmoji: false };
        }

        const coinMatch = flairString.match(/(\d+)©/);
        const gemMatch = flairString.match(/(\d+)G/);
        
        return {
            coins: coinMatch ? parseInt(coinMatch[1]) : 0,
            gems: gemMatch ? parseInt(gemMatch[1]) : 0,
            hasGoldEmoji: flairString.includes('📙'),
            hasGemEmoji: flairString.includes('📘'),
            hasOptoutEmoji: flairString.includes('📕')
        };
    }

    // Build flair string from components
    buildFlairString(coins, gems, emoji = '') {
        let flair = '';
        if (coins > 0) flair += `${coins}© `;
        if (gems > 0) flair += `${gems}G `;
        if (emoji) flair += emoji;
        return flair.trim();
    }

    // Analyze flair for deduction with configurable amounts
    analyzeFlairChanges() {
        const mode = document.querySelector('input[name="deductionMode"]:checked').value;
        const coinAmount = parseInt(document.getElementById('coinAmount').value) || 600;
        const gemAmount = parseInt(document.getElementById('gemAmount').value) || 180;
        this.pendingChanges = [];

        this.members.forEach(member => {
            const flair = this.parseFlair(member.flair);
            let newFlair = member.flair;
            let changeDescription = '';

            // Skip if member already has any emoji
            if (flair.hasGoldEmoji || flair.hasGemEmoji || flair.hasOptoutEmoji) {
                return;
            }

            if (mode === 'coin' && flair.coins >= coinAmount) {
                const newCoins = flair.coins - coinAmount;
                newFlair = this.buildFlairString(newCoins, flair.gems, '📙');
                changeDescription = `${member.flair} → ${newFlair}`;
            } else if (mode === 'gem' && flair.gems >= gemAmount) {
                const newGems = flair.gems - gemAmount;
                newFlair = this.buildFlairString(flair.coins, newGems, '📘');
                changeDescription = `${member.flair} → ${newFlair}`;
            }

            if (changeDescription) {
                this.pendingChanges.push({
                    memberId: member.playerId,
                    username: member.username,
                    oldFlair: member.flair,
                    newFlair: newFlair,
                    changeDescription: changeDescription
                });
            }
        });

        this.displayPendingChanges();
    }

    displayPendingChanges() {
        const pendingChangesDiv = document.getElementById('pendingChanges');
        const pendingChangesList = document.getElementById('pendingChangesList');

        if (this.pendingChanges.length === 0) {
            pendingChangesDiv.classList.add('d-none');
            this.showAlert('No members qualify for flair changes based on current criteria.', 'info');
            return;
        }

        pendingChangesList.innerHTML = '';
        this.pendingChanges.forEach(change => {
            const changeDiv = document.createElement('div');
            changeDiv.className = 'pending-change';
            changeDiv.innerHTML = `
                <strong>${change.username}:</strong> ${change.changeDescription}
            `;
            pendingChangesList.appendChild(changeDiv);
        });

        pendingChangesDiv.classList.remove('d-none');
    }

    async applyFlairChanges() {
        if (this.pendingChanges.length === 0) return;

        const applyBtn = document.getElementById('applyChangesBtn');
        applyBtn.disabled = true;
        applyBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Applying...';

        try {
            // Apply changes sequentially to avoid rate limiting
            for (const change of this.pendingChanges) {
                await this.updateMemberFlair(change.memberId, change.newFlair);
                
                // Update local member data
                const member = this.members.find(m => m.playerId === change.memberId);
                if (member) {
                    member.flair = change.newFlair;
                }
            }

            this.showAlert('Flair changes applied successfully!', 'success');
            this.denyFlairChanges(); // Clear pending changes
            this.renderMembersTable(); // Refresh display

        } catch (error) {
            console.error('Error applying flair changes:', error);
            this.showAlert('Failed to apply some changes. Please try again.', 'danger');
        } finally {
            applyBtn.disabled = false;
            applyBtn.innerHTML = '<i class="bx bx-check-circle"></i> Apply Changes';
        }
    }

    denyFlairChanges() {
        this.pendingChanges = [];
        document.getElementById('pendingChanges').classList.add('d-none');
    }

    // Emoji Removal Analysis
    analyzeEmojiRemoval() {
        this.pendingEmojiRemovals = [];

        this.members.forEach(member => {
            const flair = this.parseFlair(member.flair);
            
            // Check if member has any emoji
            if (flair.hasGoldEmoji || flair.hasGemEmoji || flair.hasOptoutEmoji) {
                const newFlair = this.removeEmojisFromFlair(member.flair);
                const changeDescription = `${member.flair} → ${newFlair}`;
                
                this.pendingEmojiRemovals.push({
                    memberId: member.playerId,
                    username: member.username,
                    oldFlair: member.flair,
                    newFlair: newFlair,
                    changeDescription: changeDescription
                });
            }
        });

        this.displayPendingEmojiRemoval();
    }

    displayPendingEmojiRemoval() {
        const pendingRemovalDiv = document.getElementById('pendingEmojiRemoval');
        const pendingRemovalList = document.getElementById('pendingEmojiRemovalList');

        if (this.pendingEmojiRemovals.length === 0) {
            pendingRemovalDiv.classList.add('d-none');
            this.showAlert('No members have emojis to remove.', 'info');
            return;
        }

        pendingRemovalList.innerHTML = '';
        this.pendingEmojiRemovals.forEach(change => {
            const changeDiv = document.createElement('div');
            changeDiv.className = 'pending-change';
            changeDiv.innerHTML = `
                <strong>${change.username}:</strong> ${change.changeDescription}
            `;
            pendingRemovalList.appendChild(changeDiv);
        });

        pendingRemovalDiv.classList.remove('d-none');
    }

    async applyEmojiRemoval() {
        if (this.pendingEmojiRemovals.length === 0) return;

        const applyBtn = document.getElementById('applyEmojiRemovalBtn');
        applyBtn.disabled = true;
        applyBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Removing...';

        try {
            // Apply changes sequentially to avoid rate limiting
            for (const change of this.pendingEmojiRemovals) {
                await this.updateMemberFlair(change.memberId, change.newFlair);
                
                // Update local member data
                const member = this.members.find(m => m.playerId === change.memberId);
                if (member) {
                    member.flair = change.newFlair;
                }
            }

            this.showAlert('Emojis removed successfully!', 'success');
            this.denyEmojiRemoval(); // Clear pending changes
            this.renderMembersTable(); // Refresh display

        } catch (error) {
            console.error('Error removing emojis:', error);
            this.showAlert('Failed to remove some emojis. Please try again.', 'danger');
        } finally {
            applyBtn.disabled = false;
            applyBtn.innerHTML = '<i class="bx bx-check-circle"></i> Remove All Emojis';
        }
    }

    denyEmojiRemoval() {
        this.pendingEmojiRemovals = [];
        document.getElementById('pendingEmojiRemoval').classList.add('d-none');
    }

    removeEmojisFromFlair(flairString) {
        if (!flairString || typeof flairString !== 'string') {
            return flairString;
        }
        
        // Remove all emojis        
        return flairString.replace(/[📙📘📕]/g, '').trim();
    }

    async updateMemberFlair(memberId, newFlair) {
        const clanId = this.authManager.getSelectedClanId();
        
        // Note: The actual API endpoint for updating flair may vary
        // This is a placeholder implementation
        const response = await fetch(`${this.apiBase}/clans/${clanId}/members/${memberId}/flair`, {
            method: 'PUT',
            headers: this.authManager.getHeaders(),
            body: JSON.stringify({ flair: newFlair })
        });

        if (!response.ok) {
            throw new Error(`Failed to update flair for member ${memberId}`);
        }

        return response.json();
    }

    // Quest Participation Sync
    syncAllQuests() {
        const updates = [];
        
        this.members.forEach(member => {
            const flair = this.parseFlair(member.flair);
            let shouldParticipate = member.participateInClanQuests;

            if (flair.hasGoldEmoji || flair.hasGemEmoji) {
                shouldParticipate = true;
            } else if (flair.hasOptoutEmoji) {
                shouldParticipate = false;
            } else if (!flair.hasGoldEmoji && !flair.hasGemEmoji && !flair.hasOptoutEmoji) {
                // No emoji found - turn off participate if currently on
                if (member.participateInClanQuests === true) {
                    shouldParticipate = false;
                }
            }

            if (shouldParticipate !== member.participateInClanQuests) {
                updates.push({
                    memberId: member.playerId,
                    participateInClanQuests: shouldParticipate
                });
            }
        });

        if (updates.length === 0) {
            this.showAlert('All members are already properly synced.', 'info');
            return;
        }

        this.applyQuestUpdates(updates);
    }

    async applyQuestUpdates(updates) {
        const clanId = this.authManager.getSelectedClanId();
        const syncBtn = document.getElementById('syncAllQuestsBtn');
        syncBtn.disabled = true;
        syncBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Syncing...';

        try {
            // Apply updates individually
            for (const update of updates) {
                await fetch(`${this.apiBase}/clans/${clanId}/members/${update.memberId}/participateInQuests`, {
                    method: 'PUT',
                    headers: this.authManager.getHeaders(),
                    body: JSON.stringify({ participateInQuests: update.participateInClanQuests })
                });

                // Update local member data
                const member = this.members.find(m => m.playerId === update.memberId);
                if (member) {
                    member.participateInClanQuests = update.participateInClanQuests;
                }
            }

            this.showAlert(`Quest participation synced for ${updates.length} members.`, 'success');
            this.renderMembersTable();

        } catch (error) {
            console.error('Error syncing quest participation:', error);
            this.showAlert('Failed to sync quest participation. Please try again.', 'danger');
        } finally {
            syncBtn.disabled = false;
            syncBtn.innerHTML = '<i class="bx bx-refresh"></i> Sync All to Quest';
        }
    }

    // Load members from API
    async loadMembers() {
        const clanId = this.authManager.getSelectedClanId();
        const tableBody = document.getElementById('membersTableBody');
        
        // Show loading state
        tableBody.innerHTML = `
            <tr>
                <td colspan="5" class="text-center py-4">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Loading members...</span>
                    </div>
                    <p class="text-muted mt-2">Loading clan members...</p>
                </td>
            </tr>
        `;

        try {
            const response = await fetch(`${this.apiBase}/clans/${clanId}/members`, {
                headers: this.authManager.getHeaders()
            });

            if (!response.ok) {
                if (response.status === 401) {
                    this.authManager.logout();
                    return;
                }
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }

            this.members = await response.json();
            this.renderMembersTable();

        } catch (error) {
            console.error('Error loading members:', error);
            tableBody.innerHTML = `
                <tr>
                    <td colspan="5" class="text-center py-4">
                        <div class="text-danger">
                            <i class="bx bx-error-circle display-6"></i>
                            <p class="mt-2">Failed to load members. Please try again.</p>
                            <button class="btn btn-primary" onclick="memberManager.loadMembers()">Retry</button>
                        </div>
                    </td>
                </tr>
            `;
        }
    }

    renderMembersTable() {
        const tableBody = document.getElementById('membersTableBody');
        
        if (this.members.length === 0) {
            tableBody.innerHTML = `
                <tr>
                    <td colspan="5" class="text-center py-4 text-muted">
                        <i class="bx bx-group display-6"></i>
                        <p class="mt-2">No members found in this clan.</p>
                    </td>
                </tr>
            `;
            return;
        }

        tableBody.innerHTML = '';
        this.members.forEach(member => {
            const row = this.createMemberRow(member);
            tableBody.appendChild(row);
        });
    }

    createMemberRow(member) {
        const row = document.createElement('tr');
        const flair = this.parseFlair(member.flair);
        
        const flairDisplay = member.flair || 'No flair';
        const questBadge = member.participateInClanQuests 
            ? '<span class="badge bg-success">Participating</span>'
            : '<span class="badge bg-secondary">Not Participating</span>';

        // Mobile-friendly row with responsive design
        row.innerHTML = `
            <td>
                <div class="d-flex align-items-center">
                    <span class="status-indicator status-${member.lastOnline ? 'online' : 'offline'} me-2"></span>
                    <div>
                        <strong class="d-block d-md-none">${member.username}</strong>
                        <strong class="d-none d-md-block">${member.username}</strong>
                        <small class="text-muted d-block d-md-none">Level ${member.level}</small>
                    </div>
                </div>
            </td>
            <td class="d-none d-md-table-cell">
                <span class="badge bg-primary">Level ${member.level}</span>
            </td>
            <td>
                <div class="d-flex align-items-center flex-wrap">
                    <span class="me-2 word-break">${flairDisplay}</span>
                    <div class="d-flex align-items-center">
                        ${flair.hasGoldEmoji ? '<span class="emoji-large">📙</span>' : ''}
                        ${flair.hasGemEmoji ? '<span class="emoji-large">📘</span>' : ''}
                        ${flair.hasOptoutEmoji ? '<span class="emoji-large">📕</span>' : ''}
                    </div>
                </div>
            </td>
            <td class="d-none d-md-table-cell">${questBadge}</td>
            <td>
                <div class="d-flex flex-column">
                    <button class="btn btn-sm btn-outline-primary mb-1 mb-md-0" onclick="memberManager.toggleQuestParticipation('${member.playerId}')" title="Toggle Quest Participation">
                        <i class="bx bx-toggle-${member.participateInClanQuests ? 'right' : 'left'}"></i>
                    </button>
                    <small class="text-muted d-block d-md-none mt-1">${questBadge.replace('span', 'span class="d-block"')}</small>
                </div>
            </td>
        `;

        return row;
    }

    async toggleQuestParticipation(memberId) {
        const member = this.members.find(m => m.playerId === memberId);
        if (!member) return;

        const newStatus = !member.participateInClanQuests;
        
        try {
            const clanId = this.authManager.getSelectedClanId();
            await fetch(`${this.apiBase}/clans/${clanId}/members/${memberId}/participateInQuests`, {
                method: 'PUT',
                headers: this.authManager.getHeaders(),
                body: JSON.stringify({ participateInQuests: newStatus })
            });

            member.participateInClanQuests = newStatus;
            this.renderMembersTable();
            this.showAlert('Quest participation updated.', 'success');

        } catch (error) {
            console.error('Error updating quest participation:', error);
            this.showAlert('Failed to update quest participation.', 'danger');
        }
    }

    // Load ledger entries
    async loadLedger() {
        const clanId = this.authManager.getSelectedClanId();
        const ledgerContainer = document.getElementById('ledgerContainer');

        try {
            const response = await fetch(`${this.apiBase}/clans/${clanId}/ledger`, {
                headers: this.authManager.getHeaders()
            });

            if (!response.ok) {
                throw new Error(`HTTP ${response.status}`);
            }

            const ledger = await response.json();
            this.renderLedger(ledger.slice(0, 10)); // Show last 10 entries

        } catch (error) {
            console.error('Error loading ledger:', error);
            ledgerContainer.innerHTML = '<div class="text-center text-muted py-3">Failed to load ledger</div>';
        }
    }

    renderLedger(ledger) {
        const ledgerContainer = document.getElementById('ledgerContainer');
        
        if (ledger.length === 0) {
            ledgerContainer.innerHTML = '<div class="text-center text-muted py-3">No ledger entries found</div>';
            return;
        }

        ledgerContainer.innerHTML = '';
        ledger.forEach(entry => {
            const entryDiv = document.createElement('div');
            entryDiv.className = 'ledger-entry';
            
            // Convert UTC to GMT+7 for display
            const gmt7Time = this.formatTimeForDisplay(new Date(entry.creationTime));
            const typeClass = entry.type === 'DONATE' ? 'donation' : 'quest';
            
            entryDiv.innerHTML = `
                <div class="d-flex justify-content-between align-items-start">
                    <div>
                        <strong>${entry.playerUsername}</strong>
                        <div class="small text-muted">${entry.type.replace('_', ' ')}</div>
                        <div class="small">${gmt7Time}</div>
                    </div>
                    <div class="text-end">
                        ${entry.gold > 0 ? `<div class="text-warning">${entry.gold}©</div>` : ''}
                        ${entry.gems > 0 ? `<div class="text-info">${entry.gems}G</div>` : ''}
                    </div>
                </div>
            `;
            
            ledgerContainer.appendChild(entryDiv);
        });
    }

    // Load activity logs
    async loadLogs() {
        const clanId = this.authManager.getSelectedClanId();
        const logContainer = document.getElementById('logContainer');

        try {
            const response = await fetch(`${this.apiBase}/clans/${clanId}/logs`, {
                headers: this.authManager.getHeaders()
            });

            if (!response.ok) {
                throw new Error(`HTTP ${response.status}`);
            }

            const logs = await response.json();
            this.renderLogs(logs.slice(0, 10)); // Show last 10 entries

        } catch (error) {
            console.error('Error loading logs:', error);
            logContainer.innerHTML = '<div class="text-center text-muted py-3">Failed to load logs</div>';
        }
    }

    renderLogs(logs) {
        const logContainer = document.getElementById('logContainer');
        
        if (logs.length === 0) {
            logContainer.innerHTML = '<div class="text-center text-muted py-3">No activity logs found</div>';
            return;
        }

        logContainer.innerHTML = '';
        logs.forEach(log => {
            const logDiv = document.createElement('div');
            logDiv.className = 'mb-3 pb-3 border-bottom';
            
            // Convert UTC to GMT+7 for display
            const gmt7Time = this.formatTimeForDisplay(new Date(log.creationTime));
            
            logDiv.innerHTML = `
                <div class="d-flex justify-content-between align-items-start">
                    <div>
                        <strong>${log.targetPlayerUsername || log.playerBotOwnerUsername}</strong>
                        <div class="small text-muted">${log.action.replace('_', ' ')}</div>
                    </div>
                    <div class="text-end small text-muted">
                        ${gmt7Time}
                    </div>
                </div>
            `;
            
            logContainer.appendChild(logDiv);
        });
    }

    toggleLedgerView() {
        const btn = document.getElementById('toggleLedgerBtn');
        const ledgerContainer = document.getElementById('ledgerContainer');
        const icon = btn.querySelector('i');
        
        if (this.ledgerFullView) {
            // Switch to limited view (last 10)
            this.loadLedger();
            btn.innerHTML = '<i class="bi bi-eye"></i> Show All';
            this.ledgerFullView = false;
        } else {
            // Switch to full view
            this.loadFullLedger();
            btn.innerHTML = '<i class="bi bi-eye-slash"></i> Hide Some';
            this.ledgerFullView = true;
        }
    }

    toggleLogView() {
        const btn = document.getElementById('toggleLogBtn');
        const logContainer = document.getElementById('logContainer');
        const icon = btn.querySelector('i');
        
        if (this.logFullView) {
            // Switch to limited view (last 10)
            this.loadLogs();
            btn.innerHTML = '<i class="bi bi-eye"></i> Show All';
            this.logFullView = false;
        } else {
            // Switch to full view
            this.loadFullLogs();
            btn.innerHTML = '<i class="bi bi-eye-slash"></i> Hide Some';
            this.logFullView = true;
        }
    }

    async loadFullLedger() {
        const clanId = this.authManager.getSelectedClanId();
        const ledgerContainer = document.getElementById('ledgerContainer');

        try {
            const response = await fetch(`${this.apiBase}/clans/${clanId}/ledger`, {
                headers: this.authManager.getHeaders()
            });

            if (!response.ok) {
                throw new Error(`HTTP ${response.status}`);
            }

            const ledger = await response.json();
            this.renderLedger(ledger); // Show all entries

        } catch (error) {
            console.error('Error loading full ledger:', error);
            ledgerContainer.innerHTML = '<div class="text-center text-muted py-3">Failed to load ledger</div>';
        }
    }

    async loadFullLogs() {
        const clanId = this.authManager.getSelectedClanId();
        const logContainer = document.getElementById('logContainer');

        try {
            const response = await fetch(`${this.apiBase}/clans/${clanId}/logs`, {
                headers: this.authManager.getHeaders()
            });

            if (!response.ok) {
                throw new Error(`HTTP ${response.status}`);
            }

            const logs = await response.json();
            this.renderLogs(logs); // Show all entries

        } catch (error) {
            console.error('Error loading full logs:', error);
            logContainer.innerHTML = '<div class="text-center text-muted py-3">Failed to load logs</div>';
        }
    }

    showAlert(message, type) {
        const alertContainer = document.getElementById('alertContainer');
        if (!alertContainer) return;

        const alertDiv = document.createElement('div');
        alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
        alertDiv.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        alertContainer.appendChild(alertDiv);
        
        // Auto-dismiss after 5 seconds
        setTimeout(() => {
            if (alertDiv.parentNode) {
                alertDiv.remove();
            }
        }, 5000);
    }

    // New functions for enhanced ledger and log management
    updateLatestData() {
        const btn = document.getElementById('updateLatestBtn');
        btn.disabled = true;
        btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Updating...';

        Promise.all([
            this.loadLedger(),
            this.loadLogs(),
            this.loadMembers()
        ]).then(() => {
            this.analyzeDataForUpdates();
            btn.disabled = false;
            btn.innerHTML = "<i class='bx bx-cloud-download'></i> Update Latest";
        }).catch(error => {
            console.error('Error updating data:', error);
            this.showAlert('Failed to update data. Please try again.', 'danger');
            btn.disabled = false;
            btn.innerHTML = "<i class='bx bx-cloud-download'></i> Update Latest";
        });
    }

    analyzeDataForUpdates() {
        // Compare API data with local session log and identify new entries
        const newLedgerEntries = [];
        const newLogEntries = [];
        let donationCount = 0;

        // Analyze ledger for donations (which increase update count)
        this.ledger.forEach(entry => {
            if (entry.type === 'DONATE' && this.isNewEntry(entry)) {
                donationCount++;
                newLedgerEntries.push(entry);
            }
        });

        // Analyze logs for manual changes
        this.logs.forEach(log => {
            if (this.isNewEntry(log) && this.isManualChange(log)) {
                newLogEntries.push(log);
            }
        });

        // Update the last activity time to the most recent entry
        this.updateLastActivityTime();

        // Show update status if there are new entries
        if (newLedgerEntries.length > 0 || newLogEntries.length > 0) {
            this.showUpdateStatus(newLedgerEntries.length, newLogEntries.length, donationCount);
        } else {
            this.showAlert('No new updates found. Everything is up to date!', 'info');
        }
    }

    isNewEntry(entry) {
        if (!this.lastActivityTime) return true;
        const entryTime = new Date(entry.creationTime).getTime();
        return entryTime > this.lastActivityTime;
    }

    isManualChange(log) {
        const manualActions = ['FLAIR_EDITED', 'BLACKLIST_ADDED', 'BLACKLIST_REMOVED'];
        return manualActions.includes(log.action);
    }

    updateLastActivityTime() {
        let latestTime = null;

        // Check ledger entries
        this.ledger.forEach(entry => {
            const entryTime = new Date(entry.creationTime).getTime();
            if (!latestTime || entryTime > latestTime) {
                latestTime = entryTime;
            }
        });

        // Check log entries
        this.logs.forEach(log => {
            const logTime = new Date(log.creationTime).getTime();
            if (!latestTime || logTime > latestTime) {
                latestTime = logTime;
            }
        });

        this.lastActivityTime = latestTime;
        this.displayLastActivityTime();
    }

    displayLastActivityTime() {
        const timeElement = document.getElementById('lastActivityTime');
        if (!this.lastActivityTime) {
            timeElement.textContent = 'No recent activity';
            return;
        }

        // Convert UTC to GMT+7 for display
        const gmt7Time = this.convertUTCToGMT7(new Date(this.lastActivityTime));
        const now = new Date();
        const diffMs = now.getTime() - this.lastActivityTime;
        const diffMins = Math.floor(diffMs / 60000);
        const diffHours = Math.floor(diffMs / 3600000);
        const diffDays = Math.floor(diffMs / 86400000);

        let timeAgo;
        if (diffMins < 1) {
            timeAgo = 'Just now';
        } else if (diffMins < 60) {
            timeAgo = `${diffMins} minute${diffMins > 1 ? 's' : ''} ago`;
        } else if (diffHours < 24) {
            timeAgo = `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`;
        } else {
            timeAgo = `${diffDays} day${diffDays > 1 ? 's' : ''} ago`;
        }

        timeElement.innerHTML = `
            <strong>${this.formatTimeForDisplay(gmt7Time)}</strong>
            <small class="text-muted d-block">${timeAgo}</small>
        `;
    }

    changeTimeFilter() {
        // Create a modal or prompt to change the time filter
        const currentTime = this.lastActivityTime ? this.formatTimeForInput(new Date(this.lastActivityTime)) : '';
        
        const newTime = prompt(
            'Enter the new time filter (GMT+7 - Thailand Time):\nFormat: YYYY-MM-DD HH:MM\n\nNote: All times are stored in UTC+0 internally and displayed in GMT+7',
            currentTime
        );

        if (newTime) {
            // Convert GMT+7 input to UTC for internal storage
            const gmt7Date = new Date(newTime);
            this.lastActivityTime = gmt7Date.getTime() - this.GMT7_OFFSET;
            this.displayLastActivityTime();
            this.showAlert('Time filter updated successfully!', 'success');
        }
    }

    showUpdateStatus(newLedgerCount, newLogCount, donationCount) {
        const statusDiv = document.getElementById('updateStatus');
        const statusText = document.getElementById('updateStatusText');
        
        let message = '';
        if (donationCount > 0) {
            message += `Found ${donationCount} new donation${donationCount > 1 ? 's' : ''}. `;
        }
        if (newLogCount > 0) {
            message += `Found ${newLogCount} new manual change${newLogCount > 1 ? 's' : ''}. `;
        }
        if (newLedgerCount > 0) {
            message += `Found ${newLedgerCount} new ledger entr${newLedgerCount > 1 ? 'ies' : 'y'}. `;
        }

        statusText.textContent = message || 'No new updates found.';
        statusDiv.classList.remove('d-none');
    }

    commitPendingChanges() {
        // Show a confirmation dialog with the changes summary
        const statusText = document.getElementById('updateStatusText').textContent;
        
        if (confirm(`Confirm changes:\n${statusText}\n\nDo you want to apply these updates?`)) {
            // Apply the updates (this would typically involve API calls)
            this.showAlert('Changes have been committed successfully!', 'success');
            document.getElementById('updateStatus').classList.add('d-none');
            
            // Reset the update count and refresh data
            this.updateCount = 0;
            this.loadLedgerAndLogs();
        }
    }

    filterLedger(filterType) {
        this.currentLedgerFilter = filterType;
        
        // Update button states
        document.getElementById('filterDonationsBtn').disabled = filterType === 'donations';
        document.getElementById('filterAllBtn').disabled = filterType === 'all';

        // Filter and re-render ledger
        let filteredLedger = [...this.ledger];
        
        if (filterType === 'donations') {
            filteredLedger = filteredLedger.filter(entry => entry.type === 'DONATE');
        }

        this.renderLedger(filteredLedger.slice(0, 10));
    }

    filterLogs(filterType) {
        this.currentLogFilter = filterType;
        
        // Update button states
        document.getElementById('filterFlairBtn').disabled = filterType === 'flair';
        document.getElementById('filterQuestBtn').disabled = filterType === 'quest';
        document.getElementById('filterAllActionsBtn').disabled = filterType === 'all';

        // Filter and re-render logs
        let filteredLogs = [...this.logs];
        
        if (filterType === 'flair') {
            filteredLogs = filteredLogs.filter(log => log.action === 'FLAIR_EDITED');
        } else if (filterType === 'quest') {
            const questActions = ['PLAYER_QUEST_PARTICIPATION_ENABLED', 'PLAYER_QUEST_PARTICIPATION_DISABLED'];
            filteredLogs = filteredLogs.filter(log => questActions.includes(log.action));
        }

        this.renderLogs(filteredLogs.slice(0, 10));
    }

    exportLedgerData(useUTC = false) {
        // Export ledger data with timezone option
        const exportData = this.ledger.map(entry => {
            const displayTime = useUTC 
                ? new Date(entry.creationTime).toISOString()
                : this.formatTimeForDisplay(new Date(entry.creationTime));
            
            return {
                'Date': displayTime,
                'Player': entry.playerUsername,
                'Type': entry.type,
                'Gold': entry.gold || 0,
                'Gems': entry.gems || 0,
                'Description': entry.description || ''
            };
        });

        // Convert to CSV
        const csvContent = this.convertToCSV(exportData);
        
        // Download file
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', `ledger_export_${new Date().toISOString().slice(0, 10)}.csv`);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        this.showAlert(`Ledger exported successfully (${useUTC ? 'UTC+0' : 'GMT+7'})!`, 'success');
    }

    convertToCSV(data) {
        if (data.length === 0) return '';
        
        const headers = Object.keys(data[0]);
        const csvRows = [];
        
        // Add headers
        csvRows.push(headers.join(','));
        
        // Add data rows
        data.forEach(row => {
            const values = headers.map(header => {
                const value = row[header];
                // Escape values containing commas or quotes
                if (typeof value === 'string' && (value.includes(',') || value.includes('"'))) {
                    return `"${value.replace(/"/g, '""')}"`;
                }
                return value;
            });
            csvRows.push(values.join(','));
        });
        
        return csvRows.join('\n');
    }

    loadLedgerAndLogs() {
        Promise.all([
            this.loadLedger(),
            this.loadLogs()
        ]);
    }

    // New function: Find the latest FLAIR_EDITED timestamp for default start time
    findLatestFlairEditTime() {
        if (!this.logs || this.logs.length === 0) return null;
        
        const flairEdits = this.logs.filter(log => log.action === 'FLAIR_EDITED');
        if (flairEdits.length === 0) return null;
        
        // Sort by creation time (newest first)
        flairEdits.sort((a, b) => new Date(b.creationTime).getTime() - new Date(a.creationTime).getTime());
        
        return new Date(flairEdits[0].creationTime).getTime();
    }

    // New function: Set default time range based on latest FLAIR_EDITED
    setDefaultTimeRange() {
        const latestFlairEdit = this.findLatestFlairEditTime();
        if (latestFlairEdit) {
            this.startTimeFilter = latestFlairEdit;
        } else {
            // If no FLAIR_EDITED found, use 24 hours ago as default
            this.startTimeFilter = new Date().getTime() - (24 * 60 * 60 * 1000);
        }
        this.endTimeFilter = new Date().getTime();
        this.updateTimeDisplay();
    }

    // New function: Update time display
    updateTimeDisplay() {
        const timeElement = document.getElementById('lastActivityTime');
        if (this.startTimeFilter && this.endTimeFilter) {
            const startDate = this.formatTimeForDisplay(new Date(this.startTimeFilter));
            const endDate = this.formatTimeForDisplay(new Date(this.endTimeFilter));
            const relativeTime = this.getRelativeTime(new Date(this.startTimeFilter));
            
            timeElement.innerHTML = `
                <div><strong>Processing Range:</strong></div>
                <div class="small">${startDate} - ${endDate}</div>
                <div class="small text-muted">${relativeTime}</div>
            `;
        }
    }

    // New function: Process ledger for flair updates
    processLedgerForFlairUpdates() {
        if (!this.startTimeFilter || !this.endTimeFilter) {
            this.setDefaultTimeRange();
        }

        const btn = document.getElementById('updateFlairBtn');
        btn.disabled = true;
        btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Processing...';

        // Filter ledger entries within time range and get donations
        const donationsInRange = this.ledger.filter(entry => {
            const entryTime = new Date(entry.creationTime).getTime();
            return entry.type === 'DONATE' && 
                   entryTime >= this.startTimeFilter && 
                   entryTime <= this.endTimeFilter;
        });

        if (donationsInRange.length === 0) {
            this.showAlert('No donations found in the specified time range.', 'info');
            btn.disabled = false;
            btn.innerHTML = "<i class='bx bx-coin-stack'></i> Update Flair";
            return;
        }

        // Process donations and create flair changes
        this.flairChanges = this.processDonationsForFlair(donationsInRange);

        btn.disabled = false;
        btn.innerHTML = "<i class='bx bx-coin-stack'></i> Update Flair";

        if (this.flairChanges.length > 0) {
            this.showFlairChangesConfirmation();
        } else {
            this.showAlert('No flair updates needed for the found donations.', 'info');
        }
    }

    // New function: Process donations and create flair changes
    processDonationsForFlair(donations) {
        const flairChanges = [];
        
        donations.forEach(donation => {
            const member = this.members.find(m => m.id === donation.playerId);
            if (!member) return;

            const currentFlair = this.parseFlair(member.flair);
            let newFlair = member.flair;
            let changeDescription = '';

            // Process gold donations
            if (donation.gold && donation.gold > 0) {
                const newCoins = currentFlair.coins + donation.gold;
                newFlair = this.buildFlairString(newCoins, currentFlair.gems, currentFlair.hasGoldEmoji ? '📙' : '');
                changeDescription = `${member.flair} → ${newFlair} (+${donation.gold}©)`;
            }

            // Process gem donations
            if (donation.gems && donation.gems > 0) {
                const newGems = currentFlair.gems + donation.gems;
                newFlair = this.buildFlairString(currentFlair.coins, newGems, currentFlair.hasGemEmoji ? '📘' : '');
                changeDescription = `${member.flair} → ${newFlair} (+${donation.gems}G)`;
            }

            // Only add if there's an actual change
            if (newFlair !== member.flair) {
                flairChanges.push({
                    memberId: member.id,
                    username: member.username,
                    oldFlair: member.flair,
                    newFlair: newFlair,
                    changeDescription: changeDescription,
                    donation: donation
                });
            }
        });

        return flairChanges;
    }

    // New function: Show flair changes confirmation dialog
    showFlairChangesConfirmation() {
        let changesHtml = '<div class="mb-3"><strong>Flair Changes Preview:</strong></div>';
        
        this.flairChanges.forEach((change, index) => {
            changesHtml += `
                <div class="pending-change">
                    <strong>${change.username}</strong><br>
                    <span class="text-muted">${change.changeDescription}</span>
                </div>
            `;
        });

        changesHtml += `
            <div class="d-flex gap-2 mt-3">
                <button class="btn btn-success" onclick="memberManager.applyFlairChanges()">
                    <i class='bx bx-check-circle'></i> Apply Changes
                </button>
                <button class="btn btn-secondary" onclick="memberManager.cancelFlairChanges()">
                    <i class='bx bx-x-circle'></i> Cancel
                </button>
            </div>
        `;

        document.getElementById('pendingChangesList').innerHTML = changesHtml;
        document.getElementById('pendingChanges').classList.remove('d-none');
    }

    // New function: Apply flair changes
    async applyFlairChanges() {
        if (this.flairChanges.length === 0) return;

        const btn = event.target;
        btn.disabled = true;
        btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Applying...';

        const clanId = this.authManager.getSelectedClanId();
        const results = [];

        // Apply changes sequentially to avoid rate limiting
        for (const change of this.flairChanges) {
            try {
                const response = await fetch(`https://api.wolvesville.com/clans/${clanId}/members/${change.memberId}/flair`, {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${this.authManager.getToken()}`
                    },
                    body: JSON.stringify({
                        flair: change.newFlair
                    })
                });

                if (response.ok) {
                    results.push({ success: true, change });
                    // Update local member data
                    const member = this.members.find(m => m.id === change.memberId);
                    if (member) {
                        member.flair = change.newFlair;
                    }
                } else {
                    results.push({ success: false, change, error: response.statusText });
                }
            } catch (error) {
                results.push({ success: false, change, error: error.message });
            }
        }

        btn.disabled = false;
        btn.innerHTML = "<i class='bx bx-check-circle'></i> Apply Changes";

        // Hide pending changes
        document.getElementById('pendingChanges').classList.add('d-none');

        // Show results
        const successCount = results.filter(r => r.success).length;
        const failureCount = results.filter(r => !r.success).length;

        if (successCount > 0) {
            this.showAlert(`Successfully updated ${successCount} member${successCount > 1 ? 's' : ''} flair!`, 'success');
            this.renderMembers(); // Refresh the members table
        }

        if (failureCount > 0) {
            this.showAlert(`Failed to update ${failureCount} member${failureCount > 1 ? 's' : ''}. Please try again.`, 'warning');
        }

        // Clear flair changes
        this.flairChanges = [];
    }

    // New function: Cancel flair changes
    cancelFlairChanges() {
        this.flairChanges = [];
        document.getElementById('pendingChanges').classList.add('d-none');
        this.showAlert('Flair changes cancelled.', 'info');
    }

    // New function: Get relative time
    getRelativeTime(date) {
        const now = new Date();
        const diffMs = now.getTime() - date.getTime();
        const diffMins = Math.floor(diffMs / 60000);
        const diffHours = Math.floor(diffMs / 3600000);
        const diffDays = Math.floor(diffMs / 86400000);

        if (diffMins < 1) return 'Just now';
        if (diffMins < 60) return `${diffMins} minute${diffMins > 1 ? 's' : ''} ago`;
        if (diffHours < 24) return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`;
        return `${diffDays} day${diffDays > 1 ? 's' : ''} ago`;
    }

    // Modified changeTimeFilter function
    changeTimeFilter() {
        const currentStartTime = this.startTimeFilter ? new Date(this.startTimeFilter).toISOString().slice(0, 16) : '';
        const currentEndTime = this.endTimeFilter ? new Date(this.endTimeFilter).toISOString().slice(0, 16) : '';
        
        const newStartTime = prompt(
            'Enter the start time (UTC):\nFormat: YYYY-MM-DDTHH:MM',
            currentStartTime
        );

        if (newStartTime) {
            const newEndTime = prompt(
                'Enter the end time (UTC):\nFormat: YYYY-MM-DDTHH:MM',
                currentEndTime
            );

            if (newEndTime) {
                this.startTimeFilter = new Date(newStartTime).getTime();
                this.endTimeFilter = new Date(newEndTime).getTime();
                this.updateTimeDisplay();
                this.showAlert('Time filter updated successfully!', 'success');
            }
        }
    }

    // Modified updateLastActivityTime function
    updateLastActivityTime() {
        // Set default time range based on latest FLAIR_EDITED
        this.setDefaultTimeRange();
    }
}

// Initialize member manager
const memberManager = new MemberManager();