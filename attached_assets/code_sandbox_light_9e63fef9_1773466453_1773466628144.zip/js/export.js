// Export Module for Excel and Data Management
class ExportManager {
    constructor() {
        this.apiBase = 'https://api.wolvesville.com';
        this.authManager = authManager;
        this.members = [];
        this.ledger = [];
        this.logs = [];
        this.startDate = null;
        this.endDate = null;
        
        this.init();
    }

    init() {
        // Check authentication and clan selection
        if (!this.authManager.isAuthenticated() || !this.authManager.getSelectedClanId()) {
            window.location.href = 'index.html';
            return;
        }

        // Display clan name
        const clanName = sessionStorage.getItem('wolvesville_selected_clan_name') || 'Unknown Clan';
        document.getElementById('clanNameDisplay').textContent = clanName;

        // Setup event listeners
        this.setupEventListeners();

        // Load initial data
        this.loadData();
        this.setupDateFilters();
    }

    setupEventListeners() {
        // Navigation
        document.getElementById('logoutBtn')?.addEventListener('click', () => {
            this.authManager.logout();
        });

        document.getElementById('backToMembersBtn')?.addEventListener('click', () => {
            window.location.href = 'members.html';
        });

        // Refresh
        document.getElementById('refreshAllBtn')?.addEventListener('click', () => {
            this.loadData();
        });

        // Date filter
        document.getElementById('applyFilterBtn')?.addEventListener('click', () => {
            this.applyDateFilter();
        });

        // Preset ranges
        document.getElementById('presetRange')?.addEventListener('change', (e) => {
            this.applyPresetRange(e.target.value);
        });

        // Export buttons
        document.getElementById('exportMembersBtn')?.addEventListener('click', () => {
            this.exportToExcel('members');
        });

        document.getElementById('exportLedgerBtn')?.addEventListener('click', () => {
            this.exportToExcel('ledger');
        });

        document.getElementById('exportLogBtn')?.addEventListener('click', () => {
            this.exportToExcel('logs');
        });
    }

    setupDateFilters() {
        const today = new Date();
        const lastWeek = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000);
        
        document.getElementById('startDate').value = lastWeek.toISOString().split('T')[0];
        document.getElementById('endDate').value = today.toISOString().split('T')[0];
        
        this.startDate = lastWeek;
        this.endDate = today;
    }

    applyPresetRange(preset) {
        const today = new Date();
        let startDate = new Date();
        let endDate = new Date();

        switch (preset) {
            case 'today':
                startDate.setHours(0, 0, 0, 0);
                endDate.setHours(23, 59, 59, 999);
                break;
            case 'yesterday':
                startDate.setDate(today.getDate() - 1);
                startDate.setHours(0, 0, 0, 0);
                endDate.setDate(today.getDate() - 1);
                endDate.setHours(23, 59, 59, 999);
                break;
            case 'thisWeek':
                startDate.setDate(today.getDate() - today.getDay());
                startDate.setHours(0, 0, 0, 0);
                endDate = new Date();
                break;
            case 'lastWeek':
                startDate.setDate(today.getDate() - today.getDay() - 7);
                startDate.setHours(0, 0, 0, 0);
                endDate.setDate(today.getDate() - today.getDay() - 1);
                endDate.setHours(23, 59, 59, 999);
                break;
            case 'thisMonth':
                startDate.setDate(1);
                startDate.setHours(0, 0, 0, 0);
                endDate = new Date();
                break;
            case 'lastMonth':
                startDate.setDate(1);
                startDate.setMonth(today.getMonth() - 1);
                startDate.setHours(0, 0, 0, 0);
                endDate.setDate(0);
                endDate.setHours(23, 59, 59, 999);
                break;
            case 'last7Days':
                startDate.setDate(today.getDate() - 7);
                startDate.setHours(0, 0, 0, 0);
                endDate = new Date();
                break;
            case 'last30Days':
                startDate.setDate(today.getDate() - 30);
                startDate.setHours(0, 0, 0, 0);
                endDate = new Date();
                break;
        }

        if (preset) {
            document.getElementById('startDate').value = startDate.toISOString().split('T')[0];
            document.getElementById('endDate').value = endDate.toISOString().split('T')[0];
            this.startDate = startDate;
            this.endDate = endDate;
        }
    }

    applyDateFilter() {
        const startDate = new Date(document.getElementById('startDate').value);
        const endDate = new Date(document.getElementById('endDate').value);
        
        if (startDate && endDate && startDate <= endDate) {
            this.startDate = startDate;
            this.endDate = endDate;
            this.loadData();
        } else {
            this.showAlert('Invalid date range. Please check your selection.', 'warning');
        }
    }

    async loadData() {
        const btn = document.getElementById('refreshAllBtn');
        const spinner = btn.querySelector('.spinner-border');
        
        btn.disabled = true;
        spinner.classList.remove('d-none');

        try {
            const clanId = this.authManager.getSelectedClanId();
            
            // Load all data in parallel
            const [membersResponse, ledgerResponse, logsResponse] = await Promise.all([
                fetch(`${this.apiBase}/clans/${clanId}/members`, {
                    headers: { 'Authorization': `Bearer ${this.authManager.getToken()}` }
                }),
                fetch(`${this.apiBase}/clans/${clanId}/ledger`, {
                    headers: { 'Authorization': `Bearer ${this.authManager.getToken()}` }
                }),
                fetch(`${this.apiBase}/clans/${clanId}/logs`, {
                    headers: { 'Authorization': `Bearer ${this.authManager.getToken()}` }
                })
            ]);

            if (membersResponse.ok) this.members = await membersResponse.json();
            if (ledgerResponse.ok) this.ledger = await ledgerResponse.json();
            if (logsResponse.ok) this.logs = await logsResponse.json();

            // Filter data by date range if specified
            if (this.startDate && this.endDate) {
                this.filterDataByDateRange();
            }

            this.updateDisplay();
            this.showAlert('Data loaded successfully!', 'success');

        } catch (error) {
            console.error('Error loading data:', error);
            this.showAlert('Failed to load data. Please try again.', 'danger');
        } finally {
            btn.disabled = false;
            spinner.classList.add('d-none');
        }
    }

    filterDataByDateRange() {
        if (this.startDate && this.endDate) {
            const startTime = this.startDate.getTime();
            const endTime = this.endDate.getTime();

            // Filter ledger entries
            this.ledger = this.ledger.filter(entry => {
                const entryTime = new Date(entry.creationTime).getTime();
                return entryTime >= startTime && entryTime <= endTime;
            });

            // Filter log entries
            this.logs = this.logs.filter(log => {
                const logTime = new Date(log.creationTime).getTime();
                return logTime >= startTime && logTime <= endTime;
            });
        }
    }

    updateDisplay() {
        // Update counters
        document.getElementById('membersCount').textContent = this.members.length;
        document.getElementById('ledgerEntriesCount').textContent = this.ledger.length;
        document.getElementById('logEntriesCount').textContent = this.logs.length;

        // Update statistics
        this.updateStatistics();
    }

    updateStatistics() {
        // Total members
        document.getElementById('totalMembers').textContent = this.members.length;

        // Active members (online in last 7 days)
        const sevenDaysAgo = new Date().getTime() - (7 * 24 * 60 * 60 * 1000);
        const activeMembers = this.members.filter(member => {
            const lastOnline = new Date(member.lastOnline).getTime();
            return lastOnline > sevenDaysAgo;
        }).length;
        document.getElementById('activeMembers').textContent = activeMembers;

        // Total gold and gems from ledger
        let totalGold = 0;
        let totalGems = 0;

        this.ledger.forEach(entry => {
            if (entry.gold) totalGold += entry.gold;
            if (entry.gems) totalGems += entry.gems;
        });

        document.getElementById('totalGold').textContent = totalGold.toLocaleString();
        document.getElementById('totalGems').textContent = totalGems.toLocaleString();
    }

    exportToExcel(type) {
        let data = [];
        let filename = '';
        let headers = [];

        switch (type) {
            case 'members':
                data = this.prepareMembersData();
                filename = `members_${this.formatDateForFilename()}.xlsx`;
                headers = ['Username', 'Level', 'Flair', 'Quest Status', 'Last Online', 'Join Date'];
                break;

            case 'ledger':
                data = this.prepareLedgerData();
                filename = `ledger_${this.formatDateForFilename()}.xlsx`;
                headers = ['Date', 'Player', 'Type', 'Gold', 'Gems', 'Description'];
                break;

            case 'logs':
                data = this.prepareLogsData();
                filename = `activity_log_${this.formatDateForFilename()}.xlsx`;
                headers = ['Date & Time', 'Action', 'Target Player', 'Initiated By', 'Details'];
                break;
        }

        if (data.length === 0) {
            this.showAlert(`No ${type} data available to export.`, 'warning');
            return;
        }

        // Create workbook and worksheet
        const wb = XLSX.utils.book_new();
        const ws = XLSX.utils.aoa_to_sheet([headers, ...data]);

        // Add some styling
        const range = XLSX.utils.decode_range(ws['!ref']);
        for (let R = range.s.r; R <= range.e.r; ++R) {
            for (let C = range.s.c; C <= range.e.c; ++C) {
                const cell = ws[XLSX.utils.encode_cell({ r: R, c: C })];
                if (!cell) continue;
                
                // Style header row
                if (R === 0) {
                    cell.s = {
                        font: { bold: true, color: { rgb: "FFFFFF" } },
                        fill: { fgColor: { rgb: "007BFF" } }
                    };
                }
            }
        }

        XLSX.utils.book_append_sheet(wb, ws, 'Data');
        XLSX.writeFile(wb, filename);

        this.showAlert(`Successfully exported ${type} data to Excel!`, 'success');
    }

    prepareMembersData() {
        return this.members.map(member => [
            member.username || 'Unknown',
            member.level || 0,
            member.flair || '',
            member.questParticipation ? 'Participating' : 'Not Participating',
            member.lastOnline ? new Date(member.lastOnline).toLocaleDateString() : 'Never',
            member.joinDate ? new Date(member.joinDate).toLocaleDateString() : 'Unknown'
        ]);
    }

    prepareLedgerData() {
        return this.ledger.map(entry => [
            entry.creationTime ? new Date(entry.creationTime).toLocaleDateString() : '',
            entry.playerName || entry.playerId || 'Unknown',
            entry.type || 'Unknown',
            entry.gold || 0,
            entry.gems || 0,
            entry.description || ''
        ]);
    }

    prepareLogsData() {
        return this.logs.map(log => [
            log.creationTime ? new Date(log.creationTime).toLocaleString() : '',
            log.action || 'Unknown',
            log.targetPlayerName || log.targetPlayerId || 'N/A',
            log.initiatedByName || log.initiatedById || 'System',
            log.details || ''
        ]);
    }

    formatDateForFilename() {
        const now = new Date();
        return `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}_${String(now.getHours()).padStart(2, '0')}${String(now.getMinutes()).padStart(2, '0')}`;
    }

    showAlert(message, type = 'info') {
        const alertContainer = document.getElementById('alertContainer');
        const alertId = 'alert_' + Date.now();
        
        const alertHtml = `
            <div id="${alertId}" class="alert alert-${type} alert-dismissible fade show" role="alert">
                <div class="d-flex align-items-center">
                    <i class='bx bx-${type === 'success' ? 'check-circle' : type === 'warning' ? 'error' : type === 'danger' ? 'x-circle' : 'info-circle'} me-2'></i>
                    <div>${message}</div>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        `;
        
        alertContainer.innerHTML = alertHtml;
        
        // Auto-dismiss after 5 seconds
        setTimeout(() => {
            const alert = document.getElementById(alertId);
            if (alert) {
                alert.remove();
            }
        }, 5000);
    }
}

// Initialize export manager
const exportManager = new ExportManager();