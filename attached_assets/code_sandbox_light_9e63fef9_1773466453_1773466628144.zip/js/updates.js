// Updates & History Module
class UpdatesManager {
    constructor() {
        this.apiBase = 'https://api.wolvesville.com';
        this.authManager = authManager;
        this.members = [];
        this.ledger = [];
        this.logs = [];
        this.timeline = [];
        this.currentDateFilter = null;
        this.ledgerPage = 1;
        this.logPage = 1;
        this.itemsPerPage = 50;
        
        this.init();
    }

    init() {
        // Check authentication and clan selection
        if (!this.authManager.isAuthenticated() || !this.authManager.getSelectedClanId()) {
            window.location.href = 'index.html';
            return;
        }

        // Display clan name
        const clanName = sessionStorage.getItem('wolvesville_selected_clan_name') || 'Unknown Clan';
        document.getElementById('clanNameDisplay').textContent = clanName;

        // Setup event listeners
        this.setupEventListeners();

        // Load initial data
        this.loadAllData();
        this.setupDateFilters();
    }

    setupEventListeners() {
        // Navigation
        document.getElementById('logoutBtn')?.addEventListener('click', () => {
            this.authManager.logout();
        });

        document.getElementById('backToMembersBtn')?.addEventListener('click', () => {
            window.location.href = 'members.html';
        });

        // Refresh buttons
        document.getElementById('refreshAllBtn')?.addEventListener('click', () => {
            this.loadAllData();
        });

        document.getElementById('refreshLedgerBtn')?.addEventListener('click', () => {
            this.loadLedger();
        });

        document.getElementById('refreshLogBtn')?.addEventListener('click', () => {
            this.loadLogs();
        });

        // Date filter
        document.getElementById('applyFilterBtn')?.addEventListener('click', () => {
            this.applyDateFilter();
        });

        document.getElementById('presetRange')?.addEventListener('change', (e) => {
            this.applyPresetRange(e.target.value);
        });

        // Pagination
        document.getElementById('ledgerPrevBtn')?.addEventListener('click', () => {
            this.changeLedgerPage(-1);
        });

        document.getElementById('ledgerNextBtn')?.addEventListener('click', () => {
            this.changeLedgerPage(1);
        });

        document.getElementById('logPrevBtn')?.addEventListener('click', () => {
            this.changeLogPage(-1);
        });

        document.getElementById('logNextBtn')?.addEventListener('click', () => {
            this.changeLogPage(1);
        });

        // Export buttons
        document.getElementById('exportMembersBtn')?.addEventListener('click', () => {
            this.exportMembers();
        });

        document.getElementById('exportLedgerBtn')?.addEventListener('click', () => {
            this.exportLedger();
        });

        document.getElementById('exportLogBtn')?.addEventListener('click', () => {
            this.exportLog();
        });

        // Toggle details
        document.getElementById('toggleMemberDetailsBtn')?.addEventListener('click', () => {
            this.toggleMemberDetails();
        });
    }

    setupDateFilters() {
        // Set default date range to last 30 days
        const endDate = new Date();
        const startDate = new Date();
        startDate.setDate(startDate.getDate() - 30);

        document.getElementById('startDate').value = startDate.toISOString().split('T')[0];
        document.getElementById('endDate').value = endDate.toISOString().split('T')[0];
    }

    applyPresetRange(preset) {
        const endDate = new Date();
        let startDate = new Date();

        switch (preset) {
            case 'today':
                startDate = new Date();
                break;
            case 'yesterday':
                startDate.setDate(startDate.getDate() - 1);
                endDate.setDate(endDate.getDate() - 1);
                break;
            case 'thisWeek':
                startDate.setDate(startDate.getDate() - endDate.getDay());
                break;
            case 'lastWeek':
                startDate.setDate(startDate.getDate() - endDate.getDay() - 7);
                endDate.setDate(endDate.getDate() - endDate.getDay() - 1);
                break;
            case 'thisMonth':
                startDate.setDate(1);
                break;
            case 'lastMonth':
                startDate.setMonth(startDate.getMonth() - 1, 1);
                endDate.setDate(0);
                break;
            case 'last7Days':
                startDate.setDate(startDate.getDate() - 7);
                break;
            case 'last30Days':
                startDate.setDate(startDate.getDate() - 30);
                break;
        }

        document.getElementById('startDate').value = startDate.toISOString().split('T')[0];
        document.getElementById('endDate').value = endDate.toISOString().split('T')[0];
    }

    applyDateFilter() {
        const startDate = document.getElementById('startDate').value;
        const endDate = document.getElementById('endDate').value;

        if (!startDate || !endDate) {
            this.showAlert('Please select both start and end dates.', 'warning');
            return;
        }

        if (new Date(startDate) > new Date(endDate)) {
            this.showAlert('Start date must be before or equal to end date.', 'warning');
            return;
        }

        this.currentDateFilter = {
            start: new Date(startDate).getTime(),
            end: new Date(endDate).getTime() + 86400000 // Add one day to include the end date
        };

        this.loadAllData();
        this.showAlert('Date filter applied successfully!', 'success');
    }

    async loadAllData() {
        const refreshBtn = document.getElementById('refreshAllBtn');
        const spinner = refreshBtn.querySelector('.spinner-border');
        
        refreshBtn.disabled = true;
        spinner.classList.remove('d-none');

        try {
            await Promise.all([
                this.loadMembers(),
                this.loadLedger(),
                this.loadLogs(),
                this.loadStatistics()
            ]);
        } finally {
            refreshBtn.disabled = false;
            spinner.classList.add('d-none');
        }
    }

    async loadMembers() {
        const clanId = this.authManager.getSelectedClanId();
        const tableBody = document.getElementById('completeMembersTableBody');
        
        tableBody.innerHTML = `
            <tr>
                <td colspan="7" class="text-center py-4">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Loading members...</span>
                    </div>
                    <p class="text-muted mt-2">Loading complete member list...</p>
                </td>
            </tr>
        `;

        try {
            const response = await fetch(`${this.apiBase}/clans/${clanId}/members`, {
                headers: this.authManager.getHeaders()
            });

            if (!response.ok) {
                if (response.status === 401) {
                    this.authManager.logout();
                    return;
                }
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }

            this.members = await response.json();
            this.renderCompleteMembersTable();

        } catch (error) {
            console.error('Error loading members:', error);
            tableBody.innerHTML = `
                <tr>
                    <td colspan="7" class="text-center py-4">
                        <div class="text-danger">
                            <i class="bi bi-exclamation-triangle display-6"></i>
                            <p class="mt-2">Failed to load members. Please try again.</p>
                            <button class="btn btn-primary" onclick="updatesManager.loadMembers()">Retry</button>
                        </div>
                    </td>
                </tr>
            `;
        }
    }

    renderCompleteMembersTable() {
        const tableBody = document.getElementById('completeMembersTableBody');
        
        if (this.members.length === 0) {
            tableBody.innerHTML = `
                <tr>
                    <td colspan="7" class="text-center py-4 text-muted">
                        <i class="bi bi-people display-6"></i>
                        <p class="mt-2">No members found in this clan.</p>
                    </td>
                </tr>
            `;
            return;
        }

        tableBody.innerHTML = '';
        this.members.forEach(member => {
            const row = this.createCompleteMemberRow(member);
            tableBody.appendChild(row);
        });
    }

    createCompleteMemberRow(member) {
        const row = document.createElement('tr');
        const flair = this.parseFlair(member.flair);
        const questBadge = member.participateInClanQuests 
            ? '<span class="badge bg-success">Participating</span>'
            : '<span class="badge bg-secondary">Not Participating</span>';

        const lastOnline = member.lastOnline ? 
            new Date(member.lastOnline).toLocaleDateString() : 'Unknown';
        const joinDate = member.joinDate ? 
            new Date(member.joinDate).toLocaleDateString() : 'Unknown';

        row.innerHTML = `
            <td>
                <div class="d-flex align-items-center">
                    <span class="status-indicator status-${member.lastOnline ? 'online' : 'offline'}"></span>
                    <strong>${member.username}</strong>
                </div>
            </td>
            <td>
                <span class="badge bg-primary">Level ${member.level}</span>
            </td>
            <td>
                <div class="d-flex align-items-center">
                    <span class="me-2">${member.flair || 'No flair'}</span>
                    ${flair.hasGoldEmoji ? '<span class="emoji-large">📙</span>' : ''}
                    ${flair.hasGemEmoji ? '<span class="emoji-large">📘</span>' : ''}
                    ${flair.hasOptoutEmoji ? '<span class="emoji-large">📕</span>' : ''}
                </div>
            </td>
            <td>${questBadge}</td>
            <td><small class="text-muted">${lastOnline}</small></td>
            <td><small class="text-muted">${joinDate}</small></td>
            <td>
                <button class="btn btn-sm btn-outline-primary" onclick="updatesManager.toggleMemberQuestStatus('${member.playerId}')">
                    <i class="bi bi-toggle-${member.participateInClanQuests ? 'on' : 'off'}"></i>
                </button>
            </td>
        `;

        return row;
    }

    parseFlair(flairString) {
        if (!flairString || typeof flairString !== 'string') {
            return { coins: 0, gems: 0, hasGoldEmoji: false, hasGemEmoji: false, hasOptoutEmoji: false };
        }

        const coinMatch = flairString.match(/(\d+)©/);
        const gemMatch = flairString.match(/(\d+)G/);
        
        return {
            coins: coinMatch ? parseInt(coinMatch[1]) : 0,
            gems: gemMatch ? parseInt(gemMatch[1]) : 0,
            hasGoldEmoji: flairString.includes('📙'),
            hasGemEmoji: flairString.includes('📘'),
            hasOptoutEmoji: flairString.includes('📕')
        };
    }

    async toggleMemberQuestStatus(memberId) {
        const member = this.members.find(m => m.playerId === memberId);
        if (!member) return;

        const newStatus = !member.participateInClanQuests;
        
        try {
            const clanId = this.authManager.getSelectedClanId();
            await fetch(`${this.apiBase}/clans/${clanId}/members/${memberId}/participateInQuests`, {
                method: 'PUT',
                headers: this.authManager.getHeaders(),
                body: JSON.stringify({ participateInQuests: newStatus })
            });

            member.participateInClanQuests = newStatus;
            this.renderCompleteMembersTable();
            this.showAlert('Quest participation updated.', 'success');

        } catch (error) {
            console.error('Error updating quest participation:', error);
            this.showAlert('Failed to update quest participation.', 'danger');
        }
    }

    async loadLedger() {
        const clanId = this.authManager.getSelectedClanId();
        const tableBody = document.getElementById('completeLedgerTableBody');
        
        tableBody.innerHTML = `
            <tr>
                <td colspan="6" class="text-center py-4">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Loading ledger...</span>
                    </div>
                    <p class="text-muted mt-2">Loading complete ledger history...</p>
                </td>
            </tr>
        `;

        try {
            const response = await fetch(`${this.apiBase}/clans/${clanId}/ledger`, {
                headers: this.authManager.getHeaders()
            });

            if (!response.ok) {
                throw new Error(`HTTP ${response.status}`);
            }

            this.ledger = await response.json();
            
            // Apply date filter if set
            if (this.currentDateFilter) {
                this.ledger = this.ledger.filter(entry => {
                    const entryTime = new Date(entry.creationTime).getTime();
                    return entryTime >= this.currentDateFilter.start && entryTime <= this.currentDateFilter.end;
                });
            }

            this.renderCompleteLedgerTable();

        } catch (error) {
            console.error('Error loading ledger:', error);
            tableBody.innerHTML = `
                <tr>
                    <td colspan="6" class="text-center py-4">
                        <div class="text-danger">
                            <i class="bi bi-exclamation-triangle display-6"></i>
                            <p class="mt-2">Failed to load ledger. Please try again.</p>
                            <button class="btn btn-primary" onclick="updatesManager.loadLedger()">Retry</button>
                        </div>
                    </td>
                </tr>
            `;
        }
    }

    renderCompleteLedgerTable() {
        const tableBody = document.getElementById('completeLedgerTableBody');
        const startIndex = (this.ledgerPage - 1) * this.itemsPerPage;
        const endIndex = startIndex + this.itemsPerPage;
        const pageData = this.ledger.slice(startIndex, endIndex);

        if (this.ledger.length === 0) {
            tableBody.innerHTML = `
                <tr>
                    <td colspan="6" class="text-center py-4 text-muted">
                        <i class="bi bi-journal-text display-6"></i>
                        <p class="mt-2">No ledger entries found for the selected date range.</p>
                    </td>
                </tr>
            `;
            return;
        }

        tableBody.innerHTML = '';
        pageData.forEach(entry => {
            const row = this.createLedgerRow(entry);
            tableBody.appendChild(row);
        });

        this.updatePaginationControls('ledger', this.ledger.length);
    }

    createLedgerRow(entry) {
        const row = document.createElement('tr');
        const date = new Date(entry.creationTime).toLocaleDateString();
        const time = new Date(entry.creationTime).toLocaleTimeString();
        
        row.innerHTML = `
            <td>
                <div>
                    <div>${date}</div>
                    <small class="text-muted">${time}</small>
                </div>
            </td>
            <td><strong>${entry.playerUsername}</strong></td>
            <td>
                <span class="badge bg-${entry.type === 'DONATE' ? 'success' : 'primary'}">
                    ${entry.type.replace('_', ' ')}
                </span>
            </td>
            <td class="text-end">
                ${entry.gold > 0 ? `<span class="text-warning fw-bold">${entry.gold}©</span>` : '-'}
            </td>
            <td class="text-end">
                ${entry.gems > 0 ? `<span class="text-info fw-bold">${entry.gems}G</span>` : '-'}
            </td>
            <td class="text-muted small">${entry.comment || 'No description'}</td>
        `;

        return row;
    }

    async loadLogs() {
        const clanId = this.authManager.getSelectedClanId();
        const tableBody = document.getElementById('completeLogTableBody');
        
        tableBody.innerHTML = `
            <tr>
                <td colspan="5" class="text-center py-4">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Loading logs...</span>
                    </div>
                    <p class="text-muted mt-2">Loading complete activity logs...</p>
                </td>
            </tr>
        `;

        try {
            const response = await fetch(`${this.apiBase}/clans/${clanId}/logs`, {
                headers: this.authManager.getHeaders()
            });

            if (!response.ok) {
                throw new Error(`HTTP ${response.status}`);
            }

            this.logs = await response.json();
            
            // Apply date filter if set
            if (this.currentDateFilter) {
                this.logs = this.logs.filter(log => {
                    const logTime = new Date(log.creationTime).getTime();
                    return logTime >= this.currentDateFilter.start && logTime <= this.currentDateFilter.end;
                });
            }

            this.renderCompleteLogsTable();

        } catch (error) {
            console.error('Error loading logs:', error);
            tableBody.innerHTML = `
                <tr>
                    <td colspan="5" class="text-center py-4">
                        <div class="text-danger">
                            <i class="bi bi-exclamation-triangle display-6"></i>
                            <p class="mt-2">Failed to load logs. Please try again.</p>
                            <button class="btn btn-primary" onclick="updatesManager.loadLogs()">Retry</button>
                        </div>
                    </td>
                </tr>
            `;
        }
    }

    renderCompleteLogsTable() {
        const tableBody = document.getElementById('completeLogTableBody');
        const startIndex = (this.logPage - 1) * this.itemsPerPage;
        const endIndex = startIndex + this.itemsPerPage;
        const pageData = this.logs.slice(startIndex, endIndex);

        if (this.logs.length === 0) {
            tableBody.innerHTML = `
                <tr>
                    <td colspan="5" class="text-center py-4 text-muted">
                        <i class="bi bi-list-ul display-6"></i>
                        <p class="mt-2">No activity logs found for the selected date range.</p>
                    </td>
                </tr>
            `;
            return;
        }

        tableBody.innerHTML = '';
        pageData.forEach(log => {
            const row = this.createLogRow(log);
            tableBody.appendChild(row);
        });

        this.updatePaginationControls('log', this.logs.length);
    }

    createLogRow(log) {
        const row = document.createElement('tr');
        const dateTime = new Date(log.creationTime).toLocaleString();
        
        row.innerHTML = `
            <td>
                <div>
                    <div>${dateTime}</div>
                    <small class="text-muted">${this.getTimeAgo(log.creationTime)}</small>
                </div>
            </td>
            <td>
                <span class="badge bg-${this.getActionColor(log.action)}">
                    ${log.action.replace(/_/g, ' ')}
                </span>
            </td>
            <td><strong>${log.targetPlayerUsername || 'Unknown'}</strong></td>
            <td>${log.playerBotOwnerUsername || 'System'}</td>
            <td class="text-muted small">${log.details || 'No additional details'}</td>
        `;

        return row;
    }

    getActionColor(action) {
        const colorMap = {
            'FLAIR_EDITED': 'warning',
            'PLAYER_QUEST_PARTICIPATION_ENABLED': 'success',
            'PLAYER_QUEST_PARTICIPATION_DISABLED': 'danger',
            'MEMBER_JOINED': 'info',
            'MEMBER_LEFT': 'secondary',
            'DONATION_RECEIVED': 'success',
            'QUEST_COMPLETED': 'primary'
        };
        return colorMap[action] || 'secondary';
    }

    getTimeAgo(timestamp) {
        const now = new Date().getTime();
        const diff = now - timestamp;
        const minutes = Math.floor(diff / 60000);
        const hours = Math.floor(diff / 3600000);
        const days = Math.floor(diff / 86400000);

        if (days > 0) return `${days} day${days > 1 ? 's' : ''} ago`;
        if (hours > 0) return `${hours} hour${hours > 1 ? 's' : ''} ago`;
        if (minutes > 0) return `${minutes} minute${minutes > 1 ? 's' : ''} ago`;
        return 'Just now';
    }

    updatePaginationControls(type, totalItems) {
        const currentPage = type === 'ledger' ? this.ledgerPage : this.logPage;
        const prevBtn = document.getElementById(`${type}PrevBtn`);
        const nextBtn = document.getElementById(`${type}NextBtn`);
        const countSpan = document.getElementById(`${type}Count`);

        const totalPages = Math.ceil(totalItems / this.itemsPerPage);
        const startItem = (currentPage - 1) * this.itemsPerPage + 1;
        const endItem = Math.min(currentPage * this.itemsPerPage, totalItems);

        countSpan.textContent = totalItems === 0 ? '0' : `${startItem}-${endItem} of ${totalItems}`;

        prevBtn.disabled = currentPage <= 1;
        nextBtn.disabled = currentPage >= totalPages;
    }

    changeLedgerPage(direction) {
        this.ledgerPage += direction;
        this.renderCompleteLedgerTable();
    }

    changeLogPage(direction) {
        this.logPage += direction;
        this.renderCompleteLogsTable();
    }

    async loadStatistics() {
        // Calculate statistics from loaded data
        const stats = {
            totalMembers: this.members.length,
            activeMembers: this.members.filter(m => m.lastOnline && 
                (new Date().getTime() - new Date(m.lastOnline).getTime()) < 86400000 * 7).length,
            totalGold: this.ledger.reduce((sum, entry) => sum + (entry.gold || 0), 0),
            totalGems: this.ledger.reduce((sum, entry) => sum + (entry.gems || 0), 0)
        };

        document.getElementById('totalMembers').textContent = stats.totalMembers;
        document.getElementById('activeMembers').textContent = stats.activeMembers;
        document.getElementById('totalGold').textContent = stats.totalGold.toLocaleString();
        document.getElementById('totalGems').textContent = stats.totalGems.toLocaleString();
    }

    toggleMemberDetails() {
        const btn = document.getElementById('toggleMemberDetailsBtn');
        const table = document.querySelector('#completeMembersTableBody').closest('table');
        const hiddenCols = table.querySelectorAll('th:nth-child(n+6), td:nth-child(n+6)');
        
        if (btn.textContent.includes('Show')) {
            hiddenCols.forEach(col => col.style.display = '');
            btn.innerHTML = '<i class="bi bi-eye-slash"></i> Hide Details';
        } else {
            hiddenCols.forEach(col => col.style.display = 'none');
            btn.innerHTML = '<i class="bi bi-eye"></i> Show Details';
        }
    }

    exportMembers() {
        const csvContent = this.convertToCSV(this.members, [
            'username', 'level', 'flair', 'participateInClanQuests', 'lastOnline', 'joinDate'
        ]);
        this.downloadFile(csvContent, 'members.csv', 'text/csv');
    }

    exportLedger() {
        const csvContent = this.convertToCSV(this.ledger, [
            'creationTime', 'playerUsername', 'type', 'gold', 'gems', 'description'
        ]);
        this.downloadFile(csvContent, 'ledger.csv', 'text/csv');
    }

    exportLog() {
        const csvContent = this.convertToCSV(this.logs, [
            'creationTime', 'action', 'targetPlayerUsername', 'playerBotOwnerUsername', 'details'
        ]);
        this.downloadFile(csvContent, 'activity_log.csv', 'text/csv');
    }

    convertToCSV(data, columns) {
        if (!data || data.length === 0) return '';
        
        const headers = columns.join(',');
        const rows = data.map(row => 
            columns.map(col => {
                let value = row[col] || '';
                if (typeof value === 'string' && value.includes(',')) {
                    value = `"${value}"`;
                }
                return value;
            }).join(',')
        );
        
        return [headers, ...rows].join('\n');
    }

    downloadFile(content, filename, contentType) {
        const blob = new Blob([content], { type: contentType });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
    }

    showAlert(message, type) {
        const alertContainer = document.getElementById('alertContainer');
        if (!alertContainer) return;

        const alertDiv = document.createElement('div');
        alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
        alertDiv.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        alertContainer.appendChild(alertDiv);
        
        // Auto-dismiss after 5 seconds
        setTimeout(() => {
            if (alertDiv.parentNode) {
                alertDiv.remove();
            }
        }, 5000);
    }
}

// Initialize updates manager
const updatesManager = new UpdatesManager();